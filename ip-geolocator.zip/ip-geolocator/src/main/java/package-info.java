/**
 * Package for obtaining geolocation information about IP address or host name.
 */
package geolocator;