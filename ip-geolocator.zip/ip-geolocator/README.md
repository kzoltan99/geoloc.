ip-geolocator
=============

Java class library for obtaining geolocation information of an IP address.
